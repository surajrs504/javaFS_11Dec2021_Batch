package companyLocker;
import java.io.*;
import java.util.*;

public class Locker  {
		public static final Scanner sc= new Scanner(System.in);
		static final String fpath="D:\\simplilearn assignments\\LockedMe";
		static final String errmsg="\nLooks like your input was invalid."
				+ " Please Try Again\nIf the error persist.Please contact the Admin at admin@Lockedme.com\n";
	
		/**
		 * This is menu method  displays the menu including the company name and developer details 
		 */
		public static void menu() {
		
		
		
		System.out.println("\nWelcome,Choose your option ");
		System.out.println("1) Show all the files in the directory");
		System.out.println("2) Add, Delete or Search for file in the directory");
		System.out.println("3) Exit from the application\n");
		
	}
	
		/**
		 * this method is used to display all the files in the assigned directory
		 */
	public static void getAllFiles() {
		File fobj = new File(fpath);
		String[] listOfFiles=fobj.list();
		for(var s:listOfFiles) {
			System.out.println(s);
		}
	}
	
	/**
	 * this method is used to add a new file to the directory along with lines inside the file
	 */
	public static void addfile() {
		
		
		System.out.println("Enter your filename");
		String fn= sc.nextLine();
		System.out.println("Enter the number of lines you would like to insert to your file");
		int sno= Integer.parseInt(sc.nextLine());
		try {
			FileWriter mywriter= new FileWriter(fpath+"\\"+fn);
			for(int i=1;i<=sno;i++) {
				System.out.println("Enter line "+i);
				mywriter.write(sc.nextLine()+"\n");
				
			}
			System.out.println("\nFile added");
			mywriter.close();
			
		} catch (IOException e) {
			System.out.println(errmsg);
			
		}
		
		
		
	}
	
	/**
	 * this method is used to delete file , it checks if the file exist and then deletes if if present 
	 * if the file is not present displays "file not found"
	 */
	public static void delFile() {
		
		try {
			System.out.println("Enter the file name to be deleted");
			String fname=sc.nextLine();
			File fdname=new File("D:\\simplilearn assignments\\LockedMe"+"\\"+ fname);
			if(fdname.exists()) {
				fdname.delete();
				System.out.println("\nFile deleted successfully");
			}
			else {
				System.out.println("\nFile to be deleted is missing");
			}
		}
		catch(Exception ex) {
			System.out.println(errmsg);
		}
	}
	
	/**
	 * this method performs search operation of the required file
	 * the method prints "not found" id the file is not found
	 */
	public static void searchFile() {
		boolean flag=false;
		
		File directory = new File(fpath);
		String[] fi =directory.list();
		System.out.println("Enter the file name to be searched");
		String fname=sc.nextLine();
		 if(fi==null)
			 System.out.println("\nDirectory is empty");
		 else {
			 for(var s:fi) {
				 String fdummy=s;
				 if(fdummy.equalsIgnoreCase(fname)) {
					 System.out.println("\nFile found");
					 flag=true;
				 }
				 
			 }
		 }
		 
		 if(flag==false) 
		 System.out.println("\nFile not found");
       
		
	}
	/**
	 * this is the choice method with switch statement to direct the control to specific methods.
	 */
	public static void choice() {
		do{
			
					menu();
				int ch=sc.nextInt();
				sc.nextLine();
				switch(ch) {
				case 1 :System.out.println("\nFiles in the directory:\n");
						getAllFiles();
						break;
				
				case 2:int chi=0; 
					do{
						try {
								do {
										System.out.println("would you like to:\n1) Add a file\n2) Delete a file\n"
												+ "3) Search for a file\n4) Go back to the Main Menu");
										
										int cho=sc.nextInt();
										sc.nextLine();
												if(cho==1) {
														addfile();
														continue;
												}
												else if(cho==2) {
														delFile();
														continue;
												}
												else if(cho==3) {
														searchFile();
														continue;
												}
												else if(cho==4) {
													chi=1;
													break;
												}
												else {
													System.out.println("invalid option");
												}	
									
									sc.nextLine();
								}while(true);
								
							}
							catch(InputMismatchException Ex ){
								System.out.println(errmsg);
								sc.nextLine();
							}	
						
					}while(chi==0);
						
				break;
					
				case 3:System.out.println("you have exited the application"); 
							System.exit(ch);
							
				default : System.out.println("invalid selection");
				break;
			}
							
		}while(true);
		
	}
	/**
	 * Main method with try catch statements
	 * 
	 */
	public static void main(String[] args) {
		
		System.out.println("\n"+"********************************************************************");
		System.out.println("\t\t\t\t\t\tLockedMe.com");
		System.out.println("*************************************************************************");
		System.out.println("Developer details\n\n"
				+ "Name: Suraj R Shiriya\nEmail: surajrs504@gmail.com\n");
		try {
				do{
					
					try{		
						choice();
						}
					catch(Exception ex){
						System.out.println(errmsg);
						sc.nextLine();	
						}
				
				}while(true);
			}
		
		finally {
			sc.close();
		}
		
	}

}
